import { BottomNav, Sidebar } from "./sidebar";
import { ReactNode } from "react";

export function Shell({ children }: { children: ReactNode }) {
  return (
    <div className="flex h-dvh w-full bg-background overflow-hidden selection:bg-primary/30 text-foreground">
      {/* Desktop sidebar */}
      <Sidebar />

      {/* Main content — pad bottom on mobile for bottom nav */}
      <main className="flex-1 overflow-y-auto relative pb-[68px] md:pb-0">
        {/* Background radial glow */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-primary/10 via-background to-background pointer-events-none -z-10" />
        {/* Scanline overlay */}
        <div className="absolute inset-0 pointer-events-none -z-10 scanlines opacity-[0.03]" />
        {children}
      </main>

      {/* Mobile bottom nav */}
      <BottomNav />
    </div>
  );
}
