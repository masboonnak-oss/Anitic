import { Router, type IRouter } from "express";
import {
  ConnectTikTokBody,
  UpdateTikTokSettingsBody,
} from "@workspace/api-zod";
import {
  connect,
  disconnect,
  getStatus,
  getSettings,
  updateSettings,
  getRecentEvents,
  sendTestEffect,
} from "../lib/tiktok-manager";

const router: IRouter = Router();

router.post("/tiktok/connect", async (req, res) => {
  const parsed = ConnectTikTokBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "กรุณากรอก username ให้ถูกต้อง" });
    return;
  }

  const { username } = parsed.data;

  try {
    await connect(username);
    res.json(getStatus());
  } catch (err) {
    req.log.error({ err }, "Failed to connect to TikTok LIVE");
    res.status(400).json({ error: "ไม่สามารถเชื่อมต่อได้ กรุณาตรวจสอบ username" });
  }
});

router.post("/tiktok/disconnect", async (_req, res) => {
  await disconnect();
  res.json(getStatus());
});

router.get("/tiktok/status", (_req, res) => {
  res.json(getStatus());
});

router.get("/tiktok/settings", (_req, res) => {
  res.json(getSettings());
});

router.patch("/tiktok/settings", (req, res) => {
  const parsed = UpdateTikTokSettingsBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "ข้อมูลไม่ถูกต้อง" });
    return;
  }

  const updated = updateSettings(parsed.data);
  res.json(updated);
});

router.post("/tiktok/test-effect", (_req, res) => {
  sendTestEffect();
  res.json({ success: true });
});

router.get("/tiktok/events", (_req, res) => {
  res.json(getRecentEvents());
});

export default router;
