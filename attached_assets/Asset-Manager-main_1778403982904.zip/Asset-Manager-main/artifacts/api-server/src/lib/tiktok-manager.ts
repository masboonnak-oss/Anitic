/**
 * TikTok LIVE Manager
 * ใช้ TikTokConnectionWrapper (porting จาก TikTok-Chat-Reader) เป็น capture layer
 * WebcastPushConnection → auto-reconnect → event relay → Socket.IO rooms
 */

import {
  WebcastEvent,
  ControlEvent,
} from "tiktok-live-connector";
import type {
  WebcastMemberMessage,
  WebcastChatMessage,
  WebcastGiftMessage,
  WebcastLikeMessage,
  WebcastSocialMessage,
  User,
  Image,
  FansClubMember,
} from "tiktok-live-connector";
import { logger } from "./logger";
import { emitToOverlay, emitToAdmin, emitToAll } from "./socket";
import { TikTokConnectionWrapper } from "./connection-wrapper";

// ─── Public Types ─────────────────────────────────────────────────────────────

export type ConnectionState = "OFFLINE" | "CONNECTING" | "LIVE";

export interface TikTokEvent {
  id: string;
  type: "join" | "chat" | "gift" | "like" | "follow" | "share";
  nickname: string;
  username: string;
  level: number;
  profilePictureUrl: string | null;
  message: string | null;
  giftName: string | null;
  giftCount: number | null;
  diamondCount: number | null;
  likeCount: number | null;
  timestamp: string;
  triggered: boolean;
}

export interface EffectSettings {
  minLevel: number;
  effectsEnabled: boolean;
  soundEnabled: boolean;
}

// ─── State ────────────────────────────────────────────────────────────────────

let wrapper: TikTokConnectionWrapper | null = null;
let state: ConnectionState = "OFFLINE";
let currentUsername: string | null = null;

const recentEvents: TikTokEvent[] = [];
const MAX_EVENTS = 100;

let eventCount = 0;
let highLevelCount = 0;
let giftCount = 0;

let settings: EffectSettings = {
  minLevel: 20,
  effectsEnabled: true,
  soundEnabled: true,
};

// ─── Helpers ──────────────────────────────────────────────────────────────────

function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}

function setState(newState: ConnectionState): void {
  state = newState;
  emitToAll("connection_state", {
    state,
    username: currentUsername,
    eventCount,
    highLevelCount,
    giftCount,
  });
  logger.info({ state, username: currentUsername }, "TikTok connection state changed");
}

function addEvent(event: TikTokEvent): void {
  recentEvents.unshift(event);
  if (recentEvents.length > MAX_EVENTS) recentEvents.pop();
  eventCount++;
  emitToAdmin("new_event", event);
  emitToAll("connection_state", { state, username: currentUsername, eventCount, highLevelCount, giftCount });
}

function handleHighLevelUser(event: TikTokEvent): void {
  if (!settings.effectsEnabled) return;
  highLevelCount++;
  const payload = { ...event, settings };
  emitToOverlay("high_level_join", payload);
  emitToAdmin("high_level_join", payload);
  logger.info({ nickname: event.nickname, level: event.level }, "High level user — effect triggered");
}

function getProfilePicUrl(pic: Image | undefined): string | null {
  if (!pic) return null;
  if (Array.isArray(pic.url) && pic.url.length > 0) return pic.url[0] ?? null;
  return null;
}

function getLevelFromFansClub(fansClub: FansClubMember | undefined): number {
  if (!fansClub?.data) return 0;
  return fansClub.data.level ?? 0;
}

function extractFromUser(user: User | undefined): {
  nickname: string;
  username: string;
  level: number;
  profilePictureUrl: string | null;
} {
  if (!user) return { nickname: "Unknown", username: "", level: 0, profilePictureUrl: null };
  return {
    nickname: user.nickname || "Unknown",
    username: user.uniqueId || "",
    level: getLevelFromFansClub(user.fansClub),
    profilePictureUrl: getProfilePicUrl(user.profilePicture),
  };
}

function baseEvent(
  type: TikTokEvent["type"],
  user: User | undefined,
  overrides: Partial<TikTokEvent> = {}
): TikTokEvent {
  const { nickname, username, level, profilePictureUrl } = extractFromUser(user);
  return {
    id: generateId(),
    type,
    nickname,
    username,
    level,
    profilePictureUrl,
    message: null,
    giftName: null,
    giftCount: null,
    diamondCount: null,
    likeCount: null,
    timestamp: new Date().toISOString(),
    triggered: false,
    ...overrides,
  };
}

// ─── Event Wiring ─────────────────────────────────────────────────────────────

function wireEvents(w: TikTokConnectionWrapper): void {
  const conn = w.connection;

  // ── Control ────────────────────────────────────────────────────────────────

  // connected (wrapper emits 'connected' once)
  w.once("connected", () => {
    logger.info({ username: currentUsername }, "TikTok LIVE connected");
    setState("LIVE");
  });

  // disconnected (wrapper emits when giving up / stream ended)
  w.once("disconnected", (reason: string) => {
    logger.warn({ username: currentUsername, reason }, "TikTok LIVE disconnected");
    if (state !== "OFFLINE") {
      setState("OFFLINE");
    }
  });

  // stream ended → relay to admin
  conn.on(WebcastEvent.STREAM_END, () => {
    logger.info("TikTok stream ended");
    emitToAdmin("stream_end", { username: currentUsername });
  });

  // ── เข้าห้อง (member join) ────────────────────────────────────────────────
  conn.on(WebcastEvent.MEMBER, (data: WebcastMemberMessage) => {
    const { level } = extractFromUser(data.user);
    const triggered = level >= settings.minLevel;
    const event = baseEvent("join", data.user, {
      triggered,
      message: "เข้าสู่ห้อง",
    });
    addEvent(event);
    emitToAdmin("room_join", event);
    if (triggered) handleHighLevelUser(event);
  });

  // ── แชท (chat) ────────────────────────────────────────────────────────────
  conn.on(WebcastEvent.CHAT, (data: WebcastChatMessage) => {
    const event = baseEvent("chat", data.user, {
      message: data.comment || "",
    });
    addEvent(event);
  });

  // ── ของขวัญ (gift) ────────────────────────────────────────────────────────
  // ส่งเฉพาะเมื่อ combo จบ (repeatEnd === 1) หรือ gift แบบ one-shot
  conn.on(WebcastEvent.GIFT, (data: WebcastGiftMessage) => {
    // repeatEnd === 0 หมายถึง combo ยังไม่จบ (pending streak) → รอก่อน
    const isPendingStreak = !data.repeatEnd && (data.comboCount ?? 0) > 0;
    if (isPendingStreak) return;

    const giftName = data.giftDetails?.giftName ?? `Gift #${data.giftId}`;
    const count = data.repeatCount || data.comboCount || 1;
    const diamonds = (data.giftDetails?.diamondCount ?? 0) * count;

    giftCount++;
    const event = baseEvent("gift", data.user, {
      giftName,
      giftCount: count,
      diamondCount: diamonds,
      message: `${giftName} x${count}`,
      triggered: true,
    });
    addEvent(event);
    emitToOverlay("gift_received", { ...event, settings });
    emitToAdmin("gift_received", event);
    logger.info({ nickname: event.nickname, giftName, count, diamonds }, "Gift received");
  });

  // ── ไลค์ (like) ───────────────────────────────────────────────────────────
  conn.on(WebcastEvent.LIKE, (data: WebcastLikeMessage) => {
    const event = baseEvent("like", data.user, {
      likeCount: data.likeCount || 1,
      message: `❤️ ${data.likeCount || 1} ไลค์`,
    });
    addEvent(event);
  });

  // ── ติดตาม (follow) ───────────────────────────────────────────────────────
  conn.on(WebcastEvent.FOLLOW, (data: WebcastSocialMessage) => {
    const event = baseEvent("follow", data.user, {
      message: "กดติดตาม",
    });
    addEvent(event);
  });

  // ── แชร์ (share) ──────────────────────────────────────────────────────────
  conn.on(WebcastEvent.SHARE, (data: WebcastSocialMessage) => {
    const event = baseEvent("share", data.user, {
      message: "แชร์ไลฟ์",
    });
    addEvent(event);
  });
}

// ─── Public API ───────────────────────────────────────────────────────────────

export async function connect(username: string): Promise<void> {
  // ปิด session เก่าก่อน
  if (wrapper) {
    wrapper.disconnect();
    wrapper = null;
  }

  currentUsername = username;
  eventCount = 0;
  highLevelCount = 0;
  giftCount = 0;
  recentEvents.length = 0;
  setState("CONNECTING");

  // สร้าง wrapper ใหม่ (WebcastPushConnection + auto-reconnect)
  wrapper = new TikTokConnectionWrapper(username);
  wireEvents(wrapper);
  wrapper.connect();
}

export async function disconnect(): Promise<void> {
  if (wrapper) {
    wrapper.disconnect();
    wrapper = null;
  }
  currentUsername = null;
  setState("OFFLINE");
}

export function getStatus() {
  return { state, username: currentUsername, eventCount, highLevelCount, giftCount };
}

export function getSettings(): EffectSettings {
  return { ...settings };
}

export function updateSettings(updates: Partial<EffectSettings>): EffectSettings {
  settings = { ...settings, ...updates };
  emitToAll("settings_updated", settings);
  return getSettings();
}

export function getRecentEvents(): TikTokEvent[] {
  return [...recentEvents];
}

export function sendTestEffect(): void {
  const testEvent: TikTokEvent = {
    id: generateId(),
    type: "join",
    nickname: "TestUser ทดสอบ",
    username: "testuser",
    level: 30,
    profilePictureUrl: null,
    message: "เข้าสู่ห้อง",
    giftName: null,
    giftCount: null,
    diamondCount: null,
    likeCount: null,
    timestamp: new Date().toISOString(),
    triggered: true,
  };
  emitToOverlay("high_level_join", { ...testEvent, settings });
  emitToAdmin("high_level_join", { ...testEvent, settings });
}
