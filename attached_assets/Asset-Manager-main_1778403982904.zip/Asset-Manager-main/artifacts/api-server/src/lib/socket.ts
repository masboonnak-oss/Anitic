import { Server as HttpServer } from "node:http";
import { Server as SocketServer, type Socket } from "socket.io";
import { logger } from "./logger";

let io: SocketServer | null = null;

export function initSocketIO(httpServer: HttpServer): SocketServer {
  io = new SocketServer(httpServer, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"],
    },
    path: "/api/socket.io",
  });

  io.on("connection", (socket: Socket) => {
    logger.info({ socketId: socket.id }, "Socket client connected");

    socket.on("disconnect", () => {
      logger.info({ socketId: socket.id }, "Socket client disconnected");
    });

    socket.on("join_overlay", () => {
      socket.join("overlay");
      logger.info({ socketId: socket.id }, "Client joined overlay room");
    });

    socket.on("join_admin", () => {
      socket.join("admin");
      logger.info({ socketId: socket.id }, "Client joined admin room");
    });
  });

  return io;
}

export function getIO(): SocketServer {
  if (!io) {
    throw new Error("Socket.IO not initialized");
  }
  return io;
}

export function emitToOverlay(event: string, data: unknown): void {
  if (!io) return;
  io.to("overlay").emit(event, data);
}

export function emitToAdmin(event: string, data: unknown): void {
  if (!io) return;
  io.to("admin").emit(event, data);
}

export function emitToAll(event: string, data: unknown): void {
  if (!io) return;
  io.emit(event, data);
}
