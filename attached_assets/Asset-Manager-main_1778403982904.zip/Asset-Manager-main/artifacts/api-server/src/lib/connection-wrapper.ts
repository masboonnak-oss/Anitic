/**
 * TikTokConnectionWrapper — ported from TikTok-Chat-Reader (zerodytrash)
 * Uses WebcastPushConnection with advanced auto-reconnect logic.
 *
 * Reconnect policy:
 *   - Up to 5 attempts
 *   - Exponential back-off: 1s → 2s → 4s → 8s → 16s
 *   - Stops on streamEnd or manual disconnect()
 */

import { EventEmitter } from "node:events";
import { WebcastPushConnection, ControlEvent, WebcastEvent } from "tiktok-live-connector";
import { logger } from "./logger";

let globalConnectionCount = 0;

export type WrapperEvents = {
  connected: [state: object];
  disconnected: [reason: string];
};

export class TikTokConnectionWrapper extends EventEmitter {
  readonly uniqueId: string;
  readonly connection: WebcastPushConnection;

  private clientDisconnected = false;
  private reconnectEnabled = true;
  private reconnectCount = 0;
  private reconnectWaitMs = 1000;
  private readonly maxReconnectAttempts = 5;

  constructor(
    uniqueId: string,
    options: Record<string, unknown> = {}
  ) {
    super();
    this.uniqueId = uniqueId;

    this.connection = new WebcastPushConnection(uniqueId, {
      processInitialData: false,
      enableExtendedGiftInfo: true,
      connectWithUniqueId: true,
      requestPollingIntervalMs: 2000,
      fetchRoomInfoOnConnect: true,
      sessionId: null,
      ...options,
    });

    // Disable reconnect on stream end
    this.connection.on(WebcastEvent.STREAM_END, () => {
      this.log("streamEnd event — reconnect disabled");
      this.reconnectEnabled = false;
    });

    // Auto-reconnect on drop
    this.connection.on(ControlEvent.DISCONNECTED as never, () => {
      globalConnectionCount = Math.max(0, globalConnectionCount - 1);
      this.log("Disconnected from TikTok WebSocket");
      this.scheduleReconnect();
    });

    this.connection.on(ControlEvent.ERROR as never, (err: unknown) => {
      const msg = err instanceof Error ? err.message : String(err);
      this.log(`Error: ${msg}`);
    });
  }

  /** Initiate the first connection */
  connect(isReconnect = false): void {
    this.connection
      .connect()
      .then((state) => {
        this.log(
          `${isReconnect ? "Reconnected" : "Connected"} — roomId ${(state as { roomId?: string }).roomId ?? "?"}`
        );
        globalConnectionCount++;

        // Client left while we were connecting — drop immediately
        if (this.clientDisconnected) {
          this.connection.disconnect();
          return;
        }

        // Reset back-off
        this.reconnectCount = 0;
        this.reconnectWaitMs = 1000;

        if (!isReconnect) {
          this.emit("connected", state);
        }
      })
      .catch((err: unknown) => {
        let msg = err instanceof Error ? err.message : String(err);

        // Append sub-error detail (e.g. FetchIsLiveError)
        if (
          err &&
          typeof err === "object" &&
          Array.isArray((err as { errors?: unknown[] }).errors)
        ) {
          const details = ((err as { errors: unknown[] }).errors as Error[])
            .map((e) => e?.message ?? String(e))
            .filter(Boolean)
            .join(" | ");
          if (details) msg += ": " + details;
        }

        this.log(`${isReconnect ? "Reconnect" : "Connect"} failed — ${msg}`);

        if (isReconnect) {
          this.scheduleReconnect(msg);
        } else {
          this.emit("disconnected", msg);
        }
      });
  }

  /** Schedule the next reconnect attempt */
  private scheduleReconnect(reason?: string): void {
    if (!this.reconnectEnabled) return;

    if (this.reconnectCount >= this.maxReconnectAttempts) {
      this.log("Max reconnect attempts reached — giving up");
      this.emit(
        "disconnected",
        `Connection lost${reason ? ": " + reason : ""}`
      );
      return;
    }

    this.log(`Reconnecting in ${this.reconnectWaitMs}ms…`);

    setTimeout(() => {
      if (!this.reconnectEnabled || this.reconnectCount >= this.maxReconnectAttempts) {
        return;
      }
      this.reconnectCount++;
      this.reconnectWaitMs *= 2;
      this.connect(true);
    }, this.reconnectWaitMs);
  }

  /** Permanently disconnect (called when the admin clicks "disconnect") */
  disconnect(): void {
    this.log("Client requested disconnect");
    this.clientDisconnected = true;
    this.reconnectEnabled = false;

    if (this.connection.isConnected) {
      this.connection.disconnect();
    }
  }

  private log(msg: string): void {
    logger.info({ uniqueId: this.uniqueId }, `[ConnectionWrapper] ${msg}`);
  }
}

export function getGlobalConnectionCount(): number {
  return globalConnectionCount;
}
