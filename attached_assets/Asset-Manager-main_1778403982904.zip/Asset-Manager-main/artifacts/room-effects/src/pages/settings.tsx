import { useQueryClient } from "@tanstack/react-query";
import {
  useGetTikTokSettings,
  useUpdateTikTokSettings,
  useTestEffect,
  getGetTikTokSettingsQueryKey,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { useToast } from "@/hooks/use-toast";
import { Settings as SettingsIcon, Play, Copy, Link as LinkIcon, Volume2, Zap } from "lucide-react";

export default function Settings() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: settings, isLoading } = useGetTikTokSettings({
    query: { queryKey: getGetTikTokSettingsQueryKey() },
  });

  const updateSettings = useUpdateTikTokSettings();
  const testEffect = useTestEffect();

  const handleUpdate = (updates: {
    minLevel?: number;
    effectsEnabled?: boolean;
    soundEnabled?: boolean;
  }) => {
    updateSettings.mutate(
      { data: updates },
      {
        onSuccess: (newSettings) => {
          queryClient.setQueryData(getGetTikTokSettingsQueryKey(), newSettings);
          toast({ title: "บันทึกการตั้งค่าแล้ว" });
        },
        onError: () =>
          toast({ title: "เกิดข้อผิดพลาดในการบันทึก", variant: "destructive" }),
      }
    );
  };

  const handleTestEffect = () => {
    testEffect.mutate(undefined, {
      onSuccess: () =>
        toast({ title: "ส่งเอฟเฟคทดสอบแล้ว", description: "ตรวจสอบที่หน้า Overlay" }),
    });
  };

  const copyOverlayUrl = () => {
    const url = `${window.location.origin}${import.meta.env.BASE_URL}overlay/room-effects`;
    navigator.clipboard.writeText(url);
    toast({ title: "คัดลอก URL แล้ว", description: "นำไปวางใน OBS Browser Source ได้เลย" });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-40 text-muted-foreground text-sm gap-2">
        <SettingsIcon className="w-4 h-4 animate-spin" />
        กำลังโหลด...
      </div>
    );
  }

  return (
    <div className="p-4 md:p-6 max-w-3xl mx-auto space-y-4 md:space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="w-9 h-9 rounded-xl bg-primary/20 flex items-center justify-center shadow-[0_0_12px_rgba(155,81,224,0.4)]">
          <SettingsIcon className="w-5 h-5 text-primary drop-shadow-[0_0_6px_rgba(155,81,224,0.8)]" />
        </div>
        <div>
          <h1 className="text-2xl md:text-3xl font-black neon-text-purple tracking-wider">SETTINGS</h1>
          <p className="text-xs md:text-sm text-muted-foreground">ปรับแต่งพฤติกรรมและการแสดงผลของ Overlay</p>
        </div>
      </div>

      {/* Effect settings */}
      <Card className="bg-card/40 backdrop-blur-xl border-white/5 neon-card-purple">
        <CardHeader className="pb-4">
          <CardTitle className="text-base md:text-lg flex items-center gap-2">
            <Zap className="w-4 h-4 text-primary drop-shadow-[0_0_6px_rgba(155,81,224,0.8)]" />
            การทำงานของเอฟเฟค
          </CardTitle>
          <CardDescription className="text-xs md:text-sm">เงื่อนไขที่จะทำให้เกิดเอฟเฟคในไลฟ์</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6 md:space-y-8">
          {/* Toggle effects */}
          <div className="flex items-center justify-between gap-4">
            <div className="space-y-0.5 flex-1">
              <Label className="text-sm md:text-base font-semibold">เปิดใช้งานเอฟเฟค</Label>
              <p className="text-xs text-muted-foreground">อนุญาตให้แสดงเอฟเฟคหน้าจอ</p>
            </div>
            <Switch
              checked={settings?.effectsEnabled ?? true}
              onCheckedChange={(checked) => handleUpdate({ effectsEnabled: checked })}
              data-testid="switch-effects"
            />
          </div>

          {/* Level slider */}
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <Label className="text-sm md:text-base font-semibold">Level ขั้นต่ำ</Label>
              <span className="text-2xl md:text-3xl font-black text-primary neon-text-purple">
                {settings?.minLevel ?? 20}
              </span>
            </div>
            <Slider
              value={[settings?.minLevel ?? 20]}
              min={1}
              max={50}
              step={1}
              onValueChange={(val) => handleUpdate({ minLevel: val[0] })}
              className="py-2 md:py-4"
              data-testid="slider-min-level"
            />
            <div className="flex justify-between text-[10px] text-muted-foreground">
              <span>Lv.1</span>
              <span>Lv.50</span>
            </div>
            <p className="text-xs text-muted-foreground bg-primary/5 border border-primary/15 rounded-lg px-3 py-2">
              ผู้ชม Level ตั้งแต่ <strong className="text-primary">{settings?.minLevel ?? 20}</strong> ขึ้นไปจะแสดงเอฟเฟคเมื่อเข้าห้อง
            </p>
          </div>

          {/* Toggle sound */}
          <div className="flex items-center justify-between gap-4">
            <div className="space-y-0.5 flex-1">
              <Label className="text-sm md:text-base font-semibold flex items-center gap-2">
                <Volume2 className="w-4 h-4 text-muted-foreground" />
                เสียงเอฟเฟค
              </Label>
              <p className="text-xs text-muted-foreground">เล่นเสียงพร้อมกับเอฟเฟคบนจอ</p>
            </div>
            <Switch
              checked={settings?.soundEnabled ?? true}
              onCheckedChange={(checked) => handleUpdate({ soundEnabled: checked })}
              data-testid="switch-sound"
            />
          </div>
        </CardContent>
      </Card>

      {/* OBS overlay */}
      <Card className="bg-card/40 backdrop-blur-xl border-secondary/25 shadow-[0_0_20px_rgba(236,72,153,0.06)] neon-card-pink">
        <CardHeader className="pb-4">
          <CardTitle className="text-base md:text-lg text-secondary drop-shadow-[0_0_8px_rgba(236,72,153,0.6)]">
            OBS Overlay
          </CardTitle>
          <CardDescription className="text-xs md:text-sm">
            นำ URL นี้ไปใส่ใน Browser Source ของ OBS
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* URL field */}
          <div className="flex flex-col sm:flex-row gap-2">
            <div className="relative flex-1 min-w-0">
              <LinkIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                readOnly
                value={`${window.location.origin}${import.meta.env.BASE_URL}overlay/room-effects`}
                className="pl-10 bg-background/50 border-white/10 font-mono text-xs text-muted-foreground truncate"
              />
            </div>
            <Button
              variant="secondary"
              onClick={copyOverlayUrl}
              data-testid="btn-copy"
              className="shrink-0 shadow-[0_0_10px_rgba(236,72,153,0.3)]"
            >
              <Copy className="w-4 h-4 mr-2" />
              คัดลอก
            </Button>
          </div>

          {/* OBS tips */}
          <div className="p-3 md:p-4 rounded-xl bg-white/3 border border-white/8 text-xs md:text-sm space-y-1.5 text-muted-foreground">
            <p className="font-semibold text-foreground/80">แนะนำการตั้งค่าใน OBS:</p>
            <ul className="list-disc pl-4 space-y-1">
              <li>Width: <code className="bg-white/10 px-1 rounded">1920</code>, Height: <code className="bg-white/10 px-1 rounded">1080</code></li>
              <li>เปิด "Shutdown source when not visible"</li>
              <li>พื้นหลังโปร่งใส (ไม่ต้องใส่ Chroma Key)</li>
            </ul>
          </div>
        </CardContent>
        <CardFooter className="border-t border-white/5 pt-4 md:pt-6">
          <Button
            className="w-full shadow-[0_0_20px_rgba(155,81,224,0.4)] neon-btn-purple font-bold tracking-wide"
            size="lg"
            onClick={handleTestEffect}
            data-testid="btn-test"
          >
            <Play className="w-5 h-5 mr-2" />
            ทดสอบเอฟเฟคหน้าจอ
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}
