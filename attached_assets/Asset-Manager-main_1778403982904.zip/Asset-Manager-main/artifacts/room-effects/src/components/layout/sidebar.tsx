import { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import { Gamepad2, LayoutDashboard, Settings, Wifi, WifiOff } from "lucide-react";
import { getSocket } from "@/lib/socket";

const navItems = [
  { href: "/", label: "แดชบอร์ด", Icon: LayoutDashboard },
  { href: "/settings", label: "การตั้งค่า", Icon: Settings },
] as const;

function useSocketConnected() {
  const [isConnected, setIsConnected] = useState(false);
  useEffect(() => {
    const socket = getSocket();
    const onConnect = () => setIsConnected(true);
    const onDisconnect = () => setIsConnected(false);
    socket.on("connect", onConnect);
    socket.on("disconnect", onDisconnect);
    if (socket.connected) setIsConnected(true);
    return () => {
      socket.off("connect", onConnect);
      socket.off("disconnect", onDisconnect);
    };
  }, []);
  return isConnected;
}

/** Desktop vertical sidebar — hidden on mobile */
export function Sidebar() {
  const [location] = useLocation();
  const isConnected = useSocketConnected();

  return (
    <aside className="hidden md:flex w-64 bg-sidebar border-r border-sidebar-border flex-col h-full shrink-0">
      {/* Logo */}
      <div className="h-16 flex items-center px-6 border-b border-sidebar-border bg-sidebar-accent/30 gap-3">
        <div className="relative">
          <Gamepad2 className="w-7 h-7 text-primary drop-shadow-[0_0_8px_rgba(155,81,224,0.9)]" />
          <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-primary animate-ping" />
        </div>
        <h1 className="font-black text-lg text-sidebar-foreground tracking-widest neon-text-purple">
          ROOM FX
        </h1>
      </div>

      {/* Nav */}
      <nav className="flex-1 py-6 px-4 space-y-1.5">
        {navItems.map(({ href, label, Icon }) => {
          const active = location === href;
          return (
            <Link
              key={href}
              href={href}
              className={`group flex items-center px-4 py-3 rounded-lg transition-all duration-200 gap-3 ${
                active
                  ? "bg-primary/15 text-primary font-semibold border border-primary/30 shadow-[0_0_12px_rgba(155,81,224,0.2)]"
                  : "text-sidebar-foreground/60 hover:bg-sidebar-accent hover:text-sidebar-foreground border border-transparent"
              }`}
            >
              <Icon className={`w-5 h-5 transition-all ${active ? "drop-shadow-[0_0_6px_rgba(155,81,224,0.8)]" : "group-hover:text-primary"}`} />
              <span className="text-sm">{label}</span>
              {active && (
                <span className="ml-auto w-1.5 h-1.5 rounded-full bg-primary shadow-[0_0_6px_rgba(155,81,224,1)]" />
              )}
            </Link>
          );
        })}
      </nav>

      {/* Connection status */}
      <div className="p-4 border-t border-sidebar-border">
        <div className={`flex items-center px-4 py-3 rounded-lg border gap-3 transition-all ${
          isConnected
            ? "bg-green-500/10 border-green-500/30 shadow-[0_0_10px_rgba(34,197,94,0.1)]"
            : "bg-destructive/10 border-destructive/30"
        }`}>
          {isConnected ? (
            <Wifi className="w-4 h-4 text-green-400 drop-shadow-[0_0_6px_rgba(34,197,94,0.8)]" />
          ) : (
            <WifiOff className="w-4 h-4 text-destructive" />
          )}
          <span className={`text-xs font-semibold ${isConnected ? "text-green-400" : "text-destructive"}`}>
            {isConnected ? "เซิร์ฟเวอร์เชื่อมต่อแล้ว" : "ไม่ได้เชื่อมต่อ"}
          </span>
          {isConnected && (
            <span className="ml-auto w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
          )}
        </div>
      </div>
    </aside>
  );
}

/** Mobile bottom navigation bar — visible only on mobile */
export function BottomNav() {
  const [location] = useLocation();
  const isConnected = useSocketConnected();

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-sidebar/95 backdrop-blur-xl border-t border-sidebar-border safe-area-bottom">
      {/* Neon top border line */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary to-transparent opacity-60" />

      <div className="flex items-stretch">
        {navItems.map(({ href, label, Icon }) => {
          const active = location === href;
          return (
            <Link
              key={href}
              href={href}
              className={`flex-1 flex flex-col items-center justify-center gap-1 py-3 transition-all active:scale-95 ${
                active ? "text-primary" : "text-sidebar-foreground/50"
              }`}
            >
              <div className={`relative ${active ? "drop-shadow-[0_0_8px_rgba(155,81,224,0.9)]" : ""}`}>
                <Icon className="w-5 h-5" />
                {active && (
                  <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-4 h-0.5 rounded-full bg-primary shadow-[0_0_6px_rgba(155,81,224,1)]" />
                )}
              </div>
              <span className={`text-[10px] font-semibold tracking-wide ${active ? "neon-text-purple" : ""}`}>
                {label}
              </span>
            </Link>
          );
        })}

        {/* Connection dot */}
        <div className="flex flex-col items-center justify-center px-5 gap-1">
          <div className={`w-2.5 h-2.5 rounded-full transition-all ${
            isConnected
              ? "bg-green-400 shadow-[0_0_8px_rgba(34,197,94,0.9)] animate-pulse"
              : "bg-destructive"
          }`} />
          <span className="text-[9px] font-medium text-sidebar-foreground/40">
            {isConnected ? "Online" : "Offline"}
          </span>
        </div>
      </div>
    </nav>
  );
}
