import { useEffect, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  useGetTikTokStatus,
  useGetRecentEvents,
  useConnectTikTok,
  useDisconnectTikTok,
  getGetTikTokStatusQueryKey,
  getGetRecentEventsQueryKey,
} from "@workspace/api-client-react";
import { getSocket } from "@/lib/socket";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import {
  Activity,
  Radio,
  MessageSquare,
  Zap,
  LogOut,
  Gift,
  Heart,
  UserPlus,
  Share2,
  Users,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

type EventType = "join" | "chat" | "gift" | "like" | "follow" | "share";

const EVENT_CONFIG: Record<
  EventType,
  { icon: React.ReactNode; label: string; emoji: string; color: string; rowCls: string }
> = {
  join:   { icon: <Users className="w-4 h-4" />,        emoji: "🚪", label: "เข้าห้อง", color: "text-blue-400",   rowCls: "bg-blue-500/8 border-blue-500/20" },
  chat:   { icon: <MessageSquare className="w-4 h-4" />, emoji: "💬", label: "แชท",     color: "text-slate-400",  rowCls: "bg-white/4 border-white/8" },
  gift:   { icon: <Gift className="w-4 h-4" />,          emoji: "🎁", label: "ของขวัญ", color: "text-pink-400",   rowCls: "bg-pink-500/10 border-pink-500/30" },
  like:   { icon: <Heart className="w-4 h-4" />,         emoji: "❤️", label: "ไลค์",    color: "text-red-400",    rowCls: "bg-red-500/8 border-red-500/20" },
  follow: { icon: <UserPlus className="w-4 h-4" />,      emoji: "👑", label: "ติดตาม",  color: "text-yellow-400", rowCls: "bg-yellow-500/8 border-yellow-500/20" },
  share:  { icon: <Share2 className="w-4 h-4" />,        emoji: "📢", label: "แชร์",    color: "text-green-400",  rowCls: "bg-green-500/8 border-green-500/20" },
};

const FILTER_TABS = ["all", "join", "chat", "gift", "like", "follow", "share"] as const;
type FilterTab = (typeof FILTER_TABS)[number];

export default function Dashboard() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [username, setUsername] = useState("");
  const [filter, setFilter] = useState<FilterTab>("all");

  const { data: status } = useGetTikTokStatus({
    query: { queryKey: getGetTikTokStatusQueryKey() },
  });
  const { data: recentEvents = [], isLoading: isEventsLoading } = useGetRecentEvents({
    query: { queryKey: getGetRecentEventsQueryKey() },
  });

  const connectTikTok = useConnectTikTok();
  const disconnectTikTok = useDisconnectTikTok();

  useEffect(() => {
    const socket = getSocket();
    socket.emit("join_admin");

    const onState = (s: unknown) => queryClient.setQueryData(getGetTikTokStatusQueryKey(), s);
    const onEvent = (e: unknown) =>
      queryClient.setQueryData(getGetRecentEventsQueryKey(), (old: unknown[] = []) =>
        [e, ...old].slice(0, 100)
      );
    const onHighLevel = (e: { nickname: string; level: number }) =>
      toast({ title: "👑 Level สูงเข้าห้อง!", description: `${e.nickname} (Lv.${e.level}) เข้าสู่ห้อง` });
    const onGift = (e: { nickname: string; giftName: string; giftCount: number }) =>
      toast({ title: "🎁 ได้รับของขวัญ!", description: `${e.nickname} ส่ง ${e.giftName} x${e.giftCount}` });

    socket.on("connection_state", onState);
    socket.on("new_event", onEvent);
    socket.on("high_level_join", onHighLevel);
    socket.on("gift_received", onGift);
    return () => {
      socket.off("connection_state", onState);
      socket.off("new_event", onEvent);
      socket.off("high_level_join", onHighLevel);
      socket.off("gift_received", onGift);
    };
  }, [queryClient, toast]);

  const handleConnect = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim()) return;
    connectTikTok.mutate(
      { data: { username: username.trim() } },
      {
        onSuccess: () => {
          toast({ title: "📡 กำลังเชื่อมต่อ..." });
          queryClient.invalidateQueries({ queryKey: getGetTikTokStatusQueryKey() });
        },
        onError: () =>
          toast({ title: "❌ เกิดข้อผิดพลาด", description: "ตรวจสอบ username แล้วลองใหม่", variant: "destructive" }),
      }
    );
  };

  const handleDisconnect = () => {
    disconnectTikTok.mutate(undefined, {
      onSuccess: () => {
        toast({ title: "🔌 ตัดการเชื่อมต่อแล้ว" });
        queryClient.invalidateQueries({ queryKey: getGetTikTokStatusQueryKey() });
      },
    });
  };

  const isLive = status?.state === "LIVE";
  const isConnecting = status?.state === "CONNECTING";
  const filteredEvents =
    filter === "all" ? recentEvents : recentEvents.filter((e) => e.type === filter);

  return (
    <div className="p-4 md:p-6 max-w-7xl mx-auto space-y-4 md:space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div>
          <h1 className="text-2xl md:text-3xl font-black neon-text-purple tracking-wider">
            🎮 DASHBOARD
          </h1>
          <p className="text-xs md:text-sm text-muted-foreground">ควบคุม TikTok LIVE แบบเรียลไทม์</p>
        </div>
      </div>

      {/* Connect card + stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
        {/* Connect card */}
        <Card className="md:col-span-2 border-primary/25 bg-card/40 backdrop-blur-xl neon-card-purple">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base md:text-lg">
              <Radio className="w-4 h-4 md:w-5 md:h-5 text-primary drop-shadow-[0_0_6px_rgba(155,81,224,0.8)]" />
              📡 การเชื่อมต่อ TikTok LIVE
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLive ? (
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 rounded-xl bg-green-500/10 border border-green-500/30 shadow-[0_0_20px_rgba(34,197,94,0.15)]">
                <div className="flex items-center gap-3">
                  <div className="relative flex h-4 w-4 shrink-0">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75" />
                    <span className="relative inline-flex rounded-full h-4 w-4 bg-green-500 shadow-[0_0_12px_rgba(34,197,94,0.9)]" />
                  </div>
                  <div>
                    <p className="font-black text-base md:text-lg text-green-300">🔴 LIVE — @{status?.username}</p>
                    <p className="text-xs text-muted-foreground">กำลังถ่ายทอดสด · ดักจับแชทแล้ว</p>
                  </div>
                </div>
                <Button
                  variant="destructive"
                  size="sm"
                  onClick={handleDisconnect}
                  disabled={disconnectTikTok.isPending}
                  data-testid="btn-disconnect"
                  className="w-full sm:w-auto gap-2 font-bold shadow-[0_0_14px_rgba(239,68,68,0.5)] hover:shadow-[0_0_22px_rgba(239,68,68,0.7)] transition-all"
                >
                  <LogOut className="w-4 h-4" />
                  🔌 ตัดการเชื่อมต่อ
                </Button>
              </div>
            ) : (
              <form onSubmit={handleConnect} className="flex flex-col sm:flex-row gap-3">
                <div className="relative flex-1">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-lg">@</span>
                  <Input
                    placeholder="TikTok Username ของคนที่ไลฟ์..."
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    disabled={isConnecting || connectTikTok.isPending}
                    data-testid="input-username"
                    className="pl-8 bg-background/60 border-primary/30 text-sm md:text-base py-5 md:py-6 focus-visible:ring-primary focus-visible:border-primary placeholder:text-muted-foreground/40 focus-visible:shadow-[0_0_12px_rgba(155,81,224,0.3)]"
                  />
                </div>
                <Button
                  type="submit"
                  size="lg"
                  disabled={isConnecting || connectTikTok.isPending || !username.trim()}
                  data-testid="btn-connect"
                  className="py-5 md:py-6 px-7 md:px-10 font-black text-base tracking-wider shrink-0 neon-btn-purple gap-2"
                >
                  {isConnecting || connectTikTok.isPending ? (
                    <>
                      <Activity className="w-5 h-5 animate-spin" />
                      กำลังเชื่อมต่อ...
                    </>
                  ) : (
                    <>
                      <Radio className="w-5 h-5" />
                      📡 เชื่อมต่อ
                    </>
                  )}
                </Button>
              </form>
            )}

            {isConnecting && (
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-xs text-primary/70 mt-3 flex items-center gap-1.5"
              >
                <Activity className="w-3 h-3 animate-spin" />
                กำลังเชื่อมต่อกับ TikTok LIVE... (อาจใช้เวลา 10–30 วินาที)
              </motion.p>
            )}
          </CardContent>
        </Card>

        {/* Stats */}
        <div className="grid grid-cols-3 md:grid-cols-1 gap-3 md:gap-3">
          <StatCard label="เหตุการณ์" value={status?.eventCount ?? 0}
            icon={<Activity className="w-5 h-5 text-blue-400" />}
            emoji="⚡" glow="bg-blue-500/20" />
          <StatCard label="ของขวัญ" value={status?.giftCount ?? 0}
            icon={<Gift className="w-5 h-5 text-pink-400" />}
            emoji="🎁" glow="bg-pink-500/20" valueColor="text-pink-400"
            shadow="shadow-[0_0_10px_rgba(236,72,153,0.5)]" />
          <StatCard label="Level สูง" value={status?.highLevelCount ?? 0}
            icon={<Zap className="w-5 h-5 text-primary" />}
            emoji="👑" glow="bg-primary/20" valueColor="text-primary"
            shadow="shadow-[0_0_10px_rgba(155,81,224,0.6)]" />
        </div>
      </div>

      {/* Event feed */}
      <Card className="border-white/5 bg-card/40 backdrop-blur-xl">
        <CardHeader className="pb-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <CardTitle className="flex items-center gap-2 text-base md:text-lg">
              <Activity className="w-4 h-4 md:w-5 md:h-5 text-secondary drop-shadow-[0_0_6px_rgba(236,72,153,0.8)]" />
              ⚡ เหตุการณ์แบบเรียลไทม์
            </CardTitle>
            {/* Filter tabs */}
            <div className="flex gap-1.5 overflow-x-auto pb-0.5 no-scrollbar -mx-1 px-1">
              {FILTER_TABS.map((f) => {
                const cfg = f !== "all" ? EVENT_CONFIG[f as EventType] : null;
                const label = f === "all" ? "🌟 ทั้งหมด" : `${cfg!.emoji} ${cfg!.label}`;
                return (
                  <button
                    key={f}
                    onClick={() => setFilter(f)}
                    className={`shrink-0 px-3 py-1.5 rounded-full text-xs font-bold transition-all tracking-wide border ${
                      filter === f
                        ? "bg-primary text-white shadow-[0_0_12px_rgba(155,81,224,0.7)] border-primary/60 scale-105"
                        : "bg-white/5 text-muted-foreground hover:bg-white/10 hover:text-white border-white/10 active:scale-95"
                    }`}
                  >
                    {label}
                  </button>
                );
              })}
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="h-[360px] md:h-[420px] overflow-y-auto pr-1 space-y-2 custom-scrollbar">
            {isEventsLoading ? (
              <div className="flex items-center justify-center h-full text-muted-foreground gap-2">
                <Activity className="w-5 h-5 animate-spin" />
                กำลังโหลด...
              </div>
            ) : filteredEvents.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-muted-foreground gap-3">
                <span className="text-5xl opacity-20">📭</span>
                <p className="text-sm">ยังไม่มีเหตุการณ์</p>
                <p className="text-xs opacity-50">เชื่อมต่อ TikTok LIVE เพื่อเริ่มดักจับ</p>
              </div>
            ) : (
              <AnimatePresence initial={false}>
                {filteredEvents.map((event) => {
                  const cfg = EVENT_CONFIG[event.type as EventType] ?? EVENT_CONFIG.chat;
                  const isHighlight = event.triggered || event.type === "gift";
                  return (
                    <motion.div
                      key={event.id}
                      initial={{ opacity: 0, y: -10, scale: 0.97 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      transition={{ duration: 0.16 }}
                      className={`p-3 rounded-xl border flex items-start gap-3 ${
                        isHighlight
                          ? event.type === "gift"
                            ? "bg-pink-500/10 border-pink-500/30 shadow-[0_0_12px_rgba(236,72,153,0.12)]"
                            : "bg-primary/10 border-primary/35 shadow-[0_0_12px_rgba(155,81,224,0.15)]"
                          : cfg.rowCls
                      }`}
                    >
                      <span className="text-base shrink-0 mt-0.5">{cfg.emoji}</span>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-bold text-sm text-foreground truncate max-w-[140px] sm:max-w-none">
                            {event.nickname}
                          </span>
                          {event.level > 0 && (
                            <Badge
                              variant={event.triggered ? "default" : "secondary"}
                              className={`text-[10px] px-1.5 py-0 ${event.triggered ? "shadow-[0_0_6px_rgba(155,81,224,0.5)]" : ""}`}
                            >
                              👑 Lv.{event.level}
                            </Badge>
                          )}
                          <span className="text-[10px] text-muted-foreground ml-auto whitespace-nowrap tabular-nums">
                            {new Date(event.timestamp).toLocaleTimeString("th-TH")}
                          </span>
                        </div>
                        <p className={`text-xs md:text-sm mt-0.5 break-words leading-relaxed ${event.type === "gift" ? "text-pink-300" : "text-muted-foreground"}`}>
                          {event.type === "gift"
                            ? `🎁 ${event.message}${event.diamondCount ? ` · 💎 ${event.diamondCount}` : ""}`
                            : event.message}
                        </p>
                      </div>
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function StatCard({
  label, value, icon, emoji, glow, valueColor = "text-white", shadow = "",
}: {
  label: string; value: number; icon: React.ReactNode; emoji: string;
  glow: string; valueColor?: string; shadow?: string;
}) {
  return (
    <Card className="bg-card/40 backdrop-blur-xl border-white/8 hover:border-white/15 transition-colors">
      <CardContent className="p-3 md:p-5 flex items-center gap-3 md:gap-0 md:justify-between">
        <div className={`order-last md:order-none w-10 h-10 md:w-12 md:h-12 rounded-full ${glow} flex items-center justify-center shrink-0`}>
          {icon}
        </div>
        <div>
          <p className="text-[10px] md:text-xs text-muted-foreground leading-none">{emoji} {label}</p>
          <p className={`text-xl md:text-2xl font-black mt-1 ${valueColor} ${shadow}`}>{value.toLocaleString()}</p>
        </div>
      </CardContent>
    </Card>
  );
}
