import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { getSocket } from "@/lib/socket";
import type { TikTokEvent } from "@workspace/api-client-react";

type OverlayVariant = "join" | "gift";

const isPreview = new URLSearchParams(location.search).has("preview");
const isDemo = new URLSearchParams(location.search).has("demo");

const DEMO_EVENT: QueueItem = {
  uniqueId: "demo-vip-001",
  variant: "join",
  id: "demo-1",
  type: "join",
  nickname: "BabyNoey👑",
  username: "babynoey",
  level: 30,
  profilePictureUrl: null,
  message: "เข้าสู่ห้อง",
  giftName: null,
  giftCount: null,
  diamondCount: null,
  likeCount: null,
  timestamp: new Date().toISOString(),
  triggered: true,
};

interface QueueItem extends TikTokEvent {
  uniqueId: string;
  variant: OverlayVariant;
}

function addToQueue(prev: QueueItem[], event: TikTokEvent, variant: OverlayVariant): QueueItem[] {
  const item: QueueItem = {
    ...event,
    uniqueId: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    variant,
  };
  const next = [...prev, item];
  return next.length > 3 ? next.slice(next.length - 3) : next;
}

export default function Overlay() {
  const [queue, setQueue] = useState<QueueItem[]>(isDemo ? [DEMO_EVENT] : []);
  const [flash, setFlash] = useState(false);

  useEffect(() => {
    document.documentElement.classList.add("dark");
    document.body.style.background = isPreview
      ? "linear-gradient(135deg, #0a0010 0%, #120020 50%, #0d0018 100%)"
      : "transparent";
    document.body.classList.add("overflow-hidden");

    const socket = getSocket();
    socket.emit("join_overlay");

    // auto-fire test effect in preview mode
    if (isPreview) {
      const t = setTimeout(async () => {
        try { await fetch("/api/tiktok/test-effect", { method: "POST" }); } catch { /* ignore */ }
      }, 800);
      const t2 = setTimeout(async () => {
        try { await fetch("/api/tiktok/test-effect", { method: "POST" }); } catch { /* ignore */ }
      }, 3500);
      return () => { clearTimeout(t); clearTimeout(t2); };
    }

    const dismiss = (uid: string, delay: number) => {
      setTimeout(() => setQueue((prev) => prev.filter((q) => q.uniqueId !== uid)), delay);
    };

    const onHighLevelJoin = (event: TikTokEvent) => {
      setFlash(true);
      setTimeout(() => setFlash(false), 600);
      setQueue((prev) => {
        const next = addToQueue(prev, event, "join");
        dismiss(next[next.length - 1]!.uniqueId, 6500);
        return next;
      });
    };

    const onGiftReceived = (event: TikTokEvent) => {
      setQueue((prev) => {
        const next = addToQueue(prev, event, "gift");
        dismiss(next[next.length - 1]!.uniqueId, 5000);
        return next;
      });
    };

    socket.on("high_level_join", onHighLevelJoin);
    socket.on("gift_received", onGiftReceived);

    return () => {
      socket.off("high_level_join", onHighLevelJoin);
      socket.off("gift_received", onGiftReceived);
      document.body.style.background = "";
      document.body.classList.remove("overflow-hidden");
    };
  }, []);

  return (
    <>
      {/* Preview / demo dark background */}
      {(isPreview || isDemo) && (
        <div className="fixed inset-0 -z-10" style={{
          background: "linear-gradient(135deg, #08000e 0%, #140025 40%, #0c0018 100%)"
        }} />
      )}

      {/* Divine screen flash */}
      <AnimatePresence>
        {flash && (
          <motion.div
            key="flash"
            initial={{ opacity: 0 }}
            animate={{ opacity: [0, 0.6, 0.3, 0] }}
            transition={{ duration: 0.6, times: [0, 0.1, 0.4, 1] }}
            className="fixed inset-0 pointer-events-none z-40"
            style={{ background: "radial-gradient(ellipse at center, rgba(255,200,50,0.5) 0%, rgba(200,80,255,0.3) 40%, transparent 70%)" }}
          />
        )}
      </AnimatePresence>

      <div className="fixed inset-0 pointer-events-none p-8 flex flex-col items-start justify-end gap-4 z-50">
        <AnimatePresence>
          {queue.map((item) =>
            item.variant === "gift" ? (
              <GiftCard key={item.uniqueId} item={item} />
            ) : (
              <VIPJoinCard key={item.uniqueId} item={item} />
            )
          )}
        </AnimatePresence>
      </div>
    </>
  );
}

/* ══════════════════════════════════════════════════════════
   VIP JOIN CARD — "พระเจ้าเข้าห้อง" level
   ══════════════════════════════════════════════════════════ */
function VIPJoinCard({ item }: { item: QueueItem }) {
  const isVIP = item.level >= 20;

  return (
    <motion.div
      initial={{ x: -500, opacity: 0, scale: 0.7, rotateY: -25 }}
      animate={{ x: 0, opacity: 1, scale: 1, rotateY: 0 }}
      exit={{ x: -500, opacity: 0, scale: 0.8, filter: "blur(12px)" }}
      transition={{ type: "spring", stiffness: 180, damping: 18, mass: 0.8 }}
      className="relative w-full max-w-[600px]"
      style={{ perspective: "1200px" }}
    >
      {/* Outer divine glow halo */}
      <div className="absolute -inset-6 rounded-3xl pointer-events-none"
        style={{
          background: isVIP
            ? "radial-gradient(ellipse, rgba(255,200,30,0.35) 0%, rgba(200,80,255,0.25) 40%, transparent 70%)"
            : "radial-gradient(ellipse, rgba(155,81,224,0.3) 0%, transparent 70%)",
          filter: "blur(20px)",
          animation: "divineBreath 2s ease-in-out infinite",
        }}
      />

      {/* Light rays */}
      {isVIP && (
        <div className="absolute inset-0 pointer-events-none overflow-visible" style={{ zIndex: 0 }}>
          {[...Array(12)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute left-[60px] top-[40px] origin-left"
              style={{
                width: "400px",
                height: "2px",
                rotate: `${i * 30}deg`,
                background: `linear-gradient(to right, ${i % 2 === 0 ? "rgba(255,200,50,0.8)" : "rgba(220,80,255,0.6)"}, transparent)`,
                borderRadius: "99px",
              }}
              initial={{ scaleX: 0, opacity: 0 }}
              animate={{ scaleX: [0, 1, 0.8, 1], opacity: [0, 0.9, 0.6, 0.8] }}
              transition={{ duration: 0.8 + i * 0.05, delay: 0.1, repeat: Infinity, repeatType: "reverse", repeatDelay: 0.5 }}
            />
          ))}
        </div>
      )}

      {/* Main card */}
      <div
        className="relative overflow-hidden rounded-2xl border-2 backdrop-blur-2xl"
        style={{
          background: isVIP
            ? "linear-gradient(135deg, rgba(20,8,40,0.97) 0%, rgba(40,12,60,0.97) 40%, rgba(20,8,30,0.97) 100%)"
            : "linear-gradient(135deg, rgba(15,8,35,0.97) 0%, rgba(30,10,55,0.97) 100%)",
          borderColor: isVIP ? "rgba(255,190,30,0.7)" : "rgba(155,81,224,0.6)",
          boxShadow: isVIP
            ? "0 0 40px rgba(255,190,30,0.5), 0 0 80px rgba(200,80,255,0.3), inset 0 1px 0 rgba(255,220,80,0.2)"
            : "0 0 30px rgba(155,81,224,0.6), inset 0 1px 0 rgba(155,81,224,0.2)",
        }}
      >
        {/* Top neon border sweep */}
        <motion.div
          className="absolute top-0 left-0 h-[2px] rounded-full"
          style={{
            background: isVIP
              ? "linear-gradient(to right, transparent, rgba(255,200,50,1), rgba(255,100,255,1), transparent)"
              : "linear-gradient(to right, transparent, rgba(155,81,224,1), rgba(236,72,153,1), transparent)",
          }}
          initial={{ width: "0%", left: "50%" }}
          animate={{ width: "100%", left: "0%" }}
          transition={{ duration: 0.6, ease: "easeOut" }}
        />

        {/* Scanline overlay */}
        <div className="absolute inset-0 pointer-events-none opacity-10 scanlines" />

        {/* Corner decorations */}
        <div className="absolute top-2 left-2 w-5 h-5 border-t-2 border-l-2 rounded-tl"
          style={{ borderColor: isVIP ? "rgba(255,200,50,0.8)" : "rgba(155,81,224,0.7)" }} />
        <div className="absolute top-2 right-2 w-5 h-5 border-t-2 border-r-2 rounded-tr"
          style={{ borderColor: isVIP ? "rgba(255,200,50,0.8)" : "rgba(155,81,224,0.7)" }} />
        <div className="absolute bottom-2 left-2 w-5 h-5 border-b-2 border-l-2 rounded-bl"
          style={{ borderColor: isVIP ? "rgba(255,200,50,0.8)" : "rgba(155,81,224,0.7)" }} />
        <div className="absolute bottom-2 right-2 w-5 h-5 border-b-2 border-r-2 rounded-br"
          style={{ borderColor: isVIP ? "rgba(255,200,50,0.8)" : "rgba(155,81,224,0.7)" }} />

        <div className="relative p-4 flex items-center gap-4" style={{ zIndex: 2 }}>
          {/* Avatar */}
          <motion.div
            initial={{ scale: 0, rotate: -180 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ type: "spring", stiffness: 300, damping: 20, delay: 0.2 }}
            className="relative shrink-0"
          >
            {isVIP && (
              <motion.div
                className="absolute -top-4 left-1/2 -translate-x-1/2 text-2xl"
                initial={{ y: -10, opacity: 0 }}
                animate={{ y: [0, -4, 0], opacity: 1 }}
                transition={{ delay: 0.4, y: { duration: 1.5, repeat: Infinity } }}
              >
                👑
              </motion.div>
            )}
            <div
              className="w-20 h-20 rounded-full overflow-hidden border-3 shrink-0"
              style={{
                borderColor: isVIP ? "rgba(255,200,50,0.9)" : "rgba(155,81,224,0.9)",
                boxShadow: isVIP
                  ? "0 0 20px rgba(255,180,30,0.9), 0 0 40px rgba(255,100,255,0.5)"
                  : "0 0 20px rgba(155,81,224,0.9)",
                borderWidth: "3px",
              }}
            >
              {item.profilePictureUrl ? (
                <img src={item.profilePictureUrl} alt={item.nickname} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center"
                  style={{ background: "linear-gradient(135deg, rgba(155,81,224,0.4), rgba(236,72,153,0.4))" }}>
                  <span className="text-white font-black text-2xl">{item.nickname.charAt(0)}</span>
                </div>
              )}
            </div>

            {/* Rotating ring */}
            <motion.div
              className="absolute inset-0 rounded-full border-2 border-dashed pointer-events-none"
              style={{ borderColor: isVIP ? "rgba(255,200,50,0.5)" : "rgba(155,81,224,0.5)", margin: "-4px" }}
              animate={{ rotate: 360 }}
              transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
            />
          </motion.div>

          {/* Text content */}
          <div className="flex-1 min-w-0">
            {/* Entry label */}
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.15 }}
              className="flex items-center gap-2 mb-1"
            >
              {isVIP ? (
                <span className="text-[10px] font-black tracking-[0.3em] uppercase px-2 py-0.5 rounded"
                  style={{
                    background: "linear-gradient(135deg, rgba(255,180,30,0.25), rgba(220,80,255,0.25))",
                    color: "rgba(255,210,80,0.9)",
                    border: "1px solid rgba(255,200,50,0.3)",
                  }}>
                  ✦ VIP เข้าห้อง ✦
                </span>
              ) : (
                <span className="text-[10px] font-bold tracking-widest uppercase text-primary/70">เข้าสู่ห้อง</span>
              )}
            </motion.div>

            {/* Nickname */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
            >
              <h2
                className="font-black tracking-wide leading-none mb-2"
                style={{
                  fontSize: "clamp(1.4rem, 3vw, 2rem)",
                  background: isVIP
                    ? "linear-gradient(135deg, #fff 0%, #ffd700 40%, #ff80ff 70%, #fff 100%)"
                    : "linear-gradient(135deg, #ffffff, rgba(155,81,224,0.9))",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  backgroundClip: "text",
                  textShadow: "none",
                  filter: isVIP ? "drop-shadow(0 0 12px rgba(255,200,50,0.8))" : "drop-shadow(0 0 8px rgba(155,81,224,0.8))",
                }}
              >
                {item.nickname}
              </h2>
            </motion.div>

            {/* Level + badges */}
            <motion.div
              className="flex items-center gap-2 flex-wrap"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.35 }}
            >
              <span
                className="px-3 py-1 rounded-full text-sm font-black"
                style={isVIP ? {
                  background: "linear-gradient(135deg, rgba(255,180,30,0.9), rgba(220,80,255,0.8))",
                  color: "#fff",
                  boxShadow: "0 0 14px rgba(255,180,30,0.8), 0 0 28px rgba(220,80,255,0.4)",
                  border: "1px solid rgba(255,220,80,0.4)",
                } : {
                  background: "linear-gradient(135deg, rgba(155,81,224,0.9), rgba(236,72,153,0.7))",
                  color: "#fff",
                  boxShadow: "0 0 12px rgba(155,81,224,0.7)",
                }}>
                {isVIP ? "⭐" : "🏅"} LV. {item.level}
              </span>
              {isVIP && (
                <motion.span
                  className="text-sm font-bold"
                  style={{ color: "rgba(255,210,80,0.9)" }}
                  animate={{ opacity: [1, 0.6, 1] }}
                  transition={{ duration: 1.2, repeat: Infinity }}
                >
                  ✨ ราชาผู้ยิ่งใหญ่ ✨
                </motion.span>
              )}
            </motion.div>
          </div>
        </div>

        {/* Bottom shimmer bar */}
        <motion.div
          className="absolute bottom-0 left-0 right-0 h-[1px]"
          style={{
            background: isVIP
              ? "linear-gradient(to right, transparent, rgba(255,200,50,0.8), rgba(255,80,255,0.8), transparent)"
              : "linear-gradient(to right, transparent, rgba(155,81,224,0.6), transparent)",
          }}
          animate={{ opacity: [0.5, 1, 0.5] }}
          transition={{ duration: 2, repeat: Infinity }}
        />
      </div>

      {/* Floating star particles */}
      <VIPParticles isVIP={isVIP} />
    </motion.div>
  );
}

function VIPParticles({ isVIP }: { isVIP: boolean }) {
  const count = isVIP ? 16 : 8;
  const colors = isVIP
    ? ["rgba(255,200,50,1)", "rgba(255,100,255,1)", "rgba(200,130,255,1)", "rgba(255,255,150,1)"]
    : ["rgba(155,81,224,1)", "rgba(236,72,153,1)", "rgba(200,150,255,1)"];

  return (
    <div className="absolute inset-0 pointer-events-none overflow-visible" style={{ zIndex: 3 }}>
      {[...Array(count)].map((_, i) => {
        const color = colors[i % colors.length];
        const size = isVIP ? Math.random() * 6 + 4 : Math.random() * 4 + 2;
        const angle = (i / count) * 360;
        const dist = 80 + Math.random() * 120;
        const dx = Math.cos((angle * Math.PI) / 180) * dist;
        const dy = Math.sin((angle * Math.PI) / 180) * dist;
        return (
          <motion.div
            key={i}
            className="absolute rounded-full"
            style={{
              width: size, height: size,
              left: "60px", top: "50px",
              background: color,
              boxShadow: `0 0 ${size * 3}px ${color}`,
            }}
            initial={{ x: 0, y: 0, scale: 0, opacity: 0 }}
            animate={{
              x: [0, dx * 0.5, dx],
              y: [0, dy * 0.5 - 30, dy - 40],
              scale: [0, 1.5, 0],
              opacity: [0, 1, 0],
            }}
            transition={{
              duration: 1.5 + Math.random() * 1,
              delay: 0.2 + Math.random() * 0.5,
              repeat: Infinity,
              repeatDelay: Math.random() * 2,
              ease: "easeOut",
            }}
          />
        );
      })}
    </div>
  );
}

/* ══════════════════════════════════════════════════════════
   GIFT CARD
   ══════════════════════════════════════════════════════════ */
function GiftCard({ item }: { item: QueueItem }) {
  return (
    <motion.div
      initial={{ x: -400, opacity: 0, scale: 0.75 }}
      animate={{ x: 0, opacity: 1, scale: 1 }}
      exit={{ x: -400, opacity: 0, scale: 0.8, filter: "blur(8px)" }}
      transition={{ type: "spring", stiffness: 200, damping: 22 }}
      className="relative w-full max-w-[500px]"
    >
      {/* Pink outer glow */}
      <div className="absolute -inset-4 rounded-3xl pointer-events-none"
        style={{
          background: "radial-gradient(ellipse, rgba(236,72,153,0.3) 0%, transparent 70%)",
          filter: "blur(15px)",
          animation: "divineBreath 1.8s ease-in-out infinite",
        }}
      />

      <div
        className="relative overflow-hidden rounded-2xl border-2 backdrop-blur-2xl"
        style={{
          background: "linear-gradient(135deg, rgba(40,5,30,0.97) 0%, rgba(60,10,45,0.97) 100%)",
          borderColor: "rgba(236,72,153,0.65)",
          boxShadow: "0 0 30px rgba(236,72,153,0.5), 0 0 60px rgba(180,40,120,0.25), inset 0 1px 0 rgba(255,100,200,0.15)",
        }}
      >
        {/* Top sweep */}
        <motion.div
          className="absolute top-0 left-0 h-[2px] rounded-full"
          style={{ background: "linear-gradient(to right, transparent, rgba(255,80,180,1), rgba(255,150,255,1), transparent)" }}
          initial={{ width: "0%", left: "50%" }}
          animate={{ width: "100%", left: "0%" }}
          transition={{ duration: 0.5, ease: "easeOut" }}
        />
        <div className="absolute inset-0 pointer-events-none opacity-10 scanlines" />

        <div className="relative p-4 flex items-center gap-4">
          {/* Avatar */}
          <div
            className="w-16 h-16 rounded-full overflow-hidden border-2 shrink-0"
            style={{
              borderColor: "rgba(236,72,153,0.8)",
              boxShadow: "0 0 16px rgba(236,72,153,0.8), 0 0 32px rgba(180,40,120,0.4)",
            }}
          >
            {item.profilePictureUrl ? (
              <img src={item.profilePictureUrl} alt={item.nickname} className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full flex items-center justify-center bg-pink-900/50">
                <span className="text-pink-200 font-black text-xl">{item.nickname.charAt(0)}</span>
              </div>
            )}
          </div>

          {/* Info */}
          <div className="flex-1 min-w-0">
            <p className="text-[10px] font-black tracking-[0.25em] uppercase text-pink-400/80 mb-0.5">🎁 ส่งของขวัญ</p>
            <h3
              className="font-black text-xl leading-none mb-2"
              style={{
                background: "linear-gradient(135deg, #fff, #ff80d0)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                filter: "drop-shadow(0 0 8px rgba(255,80,180,0.7))",
              }}
            >
              {item.nickname}
            </h3>
            <div className="flex items-center gap-2 flex-wrap">
              <span
                className="px-3 py-1 rounded-full text-sm font-black"
                style={{
                  background: "linear-gradient(135deg, rgba(236,72,153,0.9), rgba(180,40,120,0.9))",
                  boxShadow: "0 0 12px rgba(236,72,153,0.7)",
                  color: "#fff",
                }}
              >
                🎁 {item.giftName ?? "ของขวัญ"}
              </span>
              {item.giftCount && item.giftCount > 1 && (
                <span className="px-2 py-0.5 rounded-full text-xs font-black bg-pink-900/60 text-pink-200 border border-pink-500/40">
                  x{item.giftCount}
                </span>
              )}
              {item.diamondCount ? (
                <span className="text-xs font-bold text-pink-300/80">💎 {item.diamondCount.toLocaleString()}</span>
              ) : null}
            </div>
          </div>
        </div>

        <motion.div
          className="absolute bottom-0 left-0 right-0 h-[1px]"
          style={{ background: "linear-gradient(to right, transparent, rgba(255,80,180,0.7), transparent)" }}
          animate={{ opacity: [0.4, 1, 0.4] }}
          transition={{ duration: 1.8, repeat: Infinity }}
        />
      </div>

      {/* Gift particles */}
      <GiftParticles />
    </motion.div>
  );
}

function GiftParticles() {
  const emojis = ["🎁", "💎", "✨", "⭐", "🌟", "💫"];
  return (
    <div className="absolute inset-0 pointer-events-none overflow-visible" style={{ zIndex: 3 }}>
      {[...Array(8)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute text-lg"
          style={{ left: "40px", top: "40px" }}
          initial={{ x: 0, y: 0, scale: 0, opacity: 0, rotate: 0 }}
          animate={{
            x: (Math.random() - 0.5) * 200,
            y: -(Math.random() * 100 + 50),
            scale: [0, 1.2, 0],
            opacity: [0, 1, 0],
            rotate: (Math.random() - 0.5) * 180,
          }}
          transition={{
            duration: 1.2 + Math.random() * 0.8,
            delay: 0.1 + Math.random() * 0.6,
            repeat: Infinity,
            repeatDelay: Math.random() * 2.5,
            ease: "easeOut",
          }}
        >
          {emojis[i % emojis.length]}
        </motion.div>
      ))}
    </div>
  );
}
